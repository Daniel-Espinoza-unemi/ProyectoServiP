from django.db import models
from ..servicio.models import Servicio
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError

# Create your models here.


class Reseña(models.Model):
    servicio = models.ForeignKey(Servicio, on_delete=models.CASCADE) 
    usuario = models.ForeignKey(User, on_delete=models.CASCADE)
    texto = models.TextField()
    calificacion = models.PositiveSmallIntegerField()
    calificacion_estrellas = models.PositiveSmallIntegerField(null=True)

    def save(self, *args, **kwargs):
        if self.calificacion:
            # Verifica que la calificación esté dentro del rango de 1 a 5
            if not 1 <= self.calificacion <= 5:
                raise ValidationError("La calificación debe estar entre 1 y 5.")
            self.calificacion_estrellas = round(self.calificacion)
        super().save(*args, **kwargs)
    def __str__(self):
        return f'{self.servicio}'