from django.shortcuts import render, redirect,get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .forms import PerfilUserForm
from apps.usuario.models import Perfil


# Create your views here.

def Home(requet):
    user = requet.user.username
    print(user)
    return render(requet, 'index.html')



def registro(request):
    es = request.GET.get('es')
    if request.method == 'GET':
        form = UserCreationForm()
        formPerfilUsuario = PerfilUserForm()
        return render(request, 'registro.html', {'form': form, 'formPerfilUsuario': formPerfilUsuario})
    elif request.method == 'POST':
        form = UserCreationForm(request.POST)
        formPerfilUsuario = PerfilUserForm(request.POST)
        try:
            if form.is_valid():
                if request.POST['password1'] != request.POST['password2']:
                    return render(request, 'registro.html', {'form': form, 'error': 'Las contraseñas no coinciden'})

                user = form.save()
                
                perfil_usuario = formPerfilUsuario.save(commit=False)
                perfil_usuario.usuario = user  # Asignar el usuario al perfil antes de guardar
                perfil_usuario.rol = es
                perfil_usuario.save()
                

                # Autenticar al usuario después de registrar
                username = request.POST['username']
                password = request.POST['password1']
                authenticated_user = authenticate(request, username=username, password=password)

                if authenticated_user:
                    login(request, authenticated_user)
                    return redirect('home')
                else:
                    
                    return render(request, 'registro.html', {'form': form, 'formPerfilUsuario': formPerfilUsuario, 'error': 'Error al autenticar el usuario'})
            else:
                return render(request, 'registro.html', {'form': form, 'formPerfilUsuario': formPerfilUsuario, 'error': 'La contraseña no debe ser totalmente numerica e debe tener 8 caracteres a màs'})
        except ValueError:
            return render(request, 'registro.html', {'form': form, 'formPerfilUsuario': formPerfilUsuario, 'error': 'Error al enviar los datos'})
        
        


def login_view(request):
    form = AuthenticationForm()
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        
        if form.is_valid():
            login(request, form.get_user())
            return redirect('home')

    return render(request, 'login.html', {'form': form})


def logout_view(request):
    if request.method == 'GET':
        logout(request)
        return redirect('home')

def perfil_detail(request):
    user = request.user.username
    print(user)
    return render(request, 'perfil.html', {'perfil': user})

def trabajadorOrUsuario(request):
    return render(request, 'base/index.html')