from django.contrib import admin

from apps.usuario.models import Perfil,PerfilUsuario

# Register your models here.
admin.site.register(Perfil)
admin.site.register(PerfilUsuario)