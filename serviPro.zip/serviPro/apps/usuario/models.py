from django.db import models
from django.contrib.auth.models import User



class Perfil(models.Model):
    OPCIONES_GENERO = [
        ('M', 'Masculino'),
        ('F', 'Femenino'),
        ('O', 'Otro')
    ]
    usuario = models.OneToOneField(User, on_delete=models.CASCADE)
    foto = models.ImageField(upload_to='fotos_perfil')
    genero = models.CharField(max_length=1, choices=OPCIONES_GENERO)
    biografia = models.TextField(blank=True)
    img = models.ImageField(upload_to='perfil', null=True, blank=True)

class PerfilUsuario(models.Model):
    cedula = models.CharField(max_length=15, null=True )
    telefono = models.CharField(max_length=15, null=True)
    correo = models.EmailField(null=True)
    usuario = models.OneToOneField(User, on_delete=models.CASCADE)
    rol = models.CharField(max_length=250, choices=(('Trabajador', 'Trabajador'), ('Contratador', 'Contratador')), null=True)

    def __str__(self):
        return f'{self.cedula} - {self.correo}'

