from django.forms import ModelForm

from .models import PerfilUsuario

class PerfilUserForm(ModelForm):
    class Meta:
        model = PerfilUsuario
        fields = ['cedula', 'correo', 'correo']
    

    
        