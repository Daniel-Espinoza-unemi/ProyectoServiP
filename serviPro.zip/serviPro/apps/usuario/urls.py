from django.urls import path
from . import views



urlpatterns = [
    path('', views.Home, name='home'),
    path('registro/', views.registro, name='registro'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('perfil/', views.perfil_detail, name='perfil'),
    path('trabajadoOusuario/', views.trabajadorOrUsuario, name='traUser'),
    
]

