from django.http import Http404
from django. contrib import messages
from django.shortcuts import render, get_object_or_404, redirect
from .models import SolicitudServicio, Servicio, PerfilUsuario
from ..reseña.models import Reseña
from .forms import ContratarServiceForm, SolicitarServicesForm, ResenaForm
from datetime import datetime
from django.http import JsonResponse
from ..reseña.models import Reseña

def servicios(request):
    categorias_servicios = SolicitudServicio.objects.values_list('categoria', flat=True).distinct()
    opciones_categoria_dict = dict(SolicitudServicio.OPCIONES_CATEGORIA)
    
    categorias_info = []

    for categoria in categorias_servicios:
        solicitud_servicio = SolicitudServicio.objects.filter(categoria=categoria).first()
        if solicitud_servicio and solicitud_servicio.img:
            categorias_info.append({
                'nombre': opciones_categoria_dict[categoria],
                'imagen': solicitud_servicio.img.url
            })
    print(categorias_info)
    datos = SolicitudServicio.objects.all()
    
    return render(request, 'servicios.html', {'categorias_servicios': categorias_info, 'datos': datos})





def contratar_servicio(request, id_categoria_servicio):
    solicitud_servicio = get_object_or_404(SolicitudServicio, id=id_categoria_servicio)

    # Verificar si el usuario actual tiene el rol de "Trabajador"
    if not hasattr(request.user, 'perfilusuario') or request.user.perfilusuario.rol != 'Trabajador':
        messages.warning(request, 'No tienes permisos para contratar servicios o no has creado un perfil.')
        return redirect('servicios')  # Puedes redirigir a donde desees

    # Verificar si ya existe un servicio para esta solicitud
    if Servicio.objects.filter(solicitud=solicitud_servicio).exists():
        messages.warning(request, 'Ya has contratado este servicio anteriormente.')
        return redirect('servicios')  # Puedes redirigir a donde desees

    # Crear un nuevo servicio y asociarlo a la solicitud actual
    nuevo_servicio = Servicio(solicitud=solicitud_servicio, trabajador=request.user.perfilusuario, aceptado_en=datetime.now())
    nuevo_servicio.save()

    # Puedes mostrar un mensaje de éxito si lo deseas
    messages.success(request, f'Servicio contratado con éxito: {solicitud_servicio.get_categoria_display_name()}')

    return redirect('servicios')  # Puedes redirigir a donde desees


def ver_trabajadores_servicio(request, categoria_servicio):
    try:
        OPCIONES_CATEGORIA = [
            ('C', 'Carpintería'),
            ('P', 'Plomería'),
            ('E', 'Electricidad'),
            ('L', 'Limpieza')
        ]

        # Obtener la categoría correspondiente según categoria_servicio
        for codigo, nombre in OPCIONES_CATEGORIA:
            if nombre.lower() == categoria_servicio.lower():
                categoria = SolicitudServicio.objects.filter(categoria=codigo)
                break
        else:
            # El bloque else se ejecutará si el bucle no se rompe (no se encuentra la categoría)
            raise ValueError("Categoría no válida")

    except PerfilUsuario.DoesNotExist:
        raise Http404("No hay trabajadores disponibles para este servicio")

    return render(request, 'ver_trabajadores.html', {'categoria_servicio': categoria_servicio, 'categoria': categoria})

def MeServicioTrabajador(request):
    if request.method == 'GET':
        servicios = Servicio.objects.filter(trabajador=request.user.perfilusuario)
        form_resena = ResenaForm()  # Instancia del formulario de reseñas
        return render(request, 'contratar/verServicio.html', {'servicios': servicios, 'form_resena': form_resena})
    elif request.method == 'POST':
        form_resena = ResenaForm(request.POST)
        if form_resena.is_valid():
            servicio_id = form_resena.cleaned_data['servicio_id']
            texto = form_resena.cleaned_data['texto']
            calificacion = form_resena.cleaned_data['calificacion']

            # Verifica si ya existe una reseña para el servicio
            if  Reseña.objects.filter(servicio_id=servicio_id, usuario=request.user).exists():
                messages.error(request, 'Ya has dejado una reseña para este servicio.')
            else:
                # Crea la nueva reseña
                Reseña.objects.create(servicio_id=servicio_id, usuario=request.user, texto=texto, calificacion=calificacion)
                messages.success(request, 'Reseña agregada exitosamente.')
    
    return redirect('MeServiciosTrabajador')  # Cambia 'perfil' por la ruta adecuada
    
def ver_resenas(request, servicio_id):
    servicio = get_object_or_404(Servicio, id=servicio_id)
    reseñas = Reseña.objects.filter(servicio=servicio)
    return render(request, 'contratar/ver_resenas.html', {'servicio': servicio, 'reseñas': reseñas})


    
    
def SolicitarServices(request):
    if request.method == 'GET':
        formSolicitarServices = SolicitarServicesForm()
        return render(request, 'solicitarServicio/solicitarServicio.html', {'formSolicitarServices': formSolicitarServices})
    else:
        formSolicitarServices = SolicitarServicesForm(request.POST)
        
        try:
            if formSolicitarServices.is_valid():
                nueva_solicitud = formSolicitarServices.save(commit=False)
                nueva_solicitud.solicitado_por = request.user

                # Verificar si ya existe una solicitud en la misma categoría para el usuario actual
                categoria_existente = SolicitudServicio.objects.filter(
                    solicitado_por=request.user,
                    categoria=nueva_solicitud.categoria
                ).exists()

                if categoria_existente:
                    messages.warning(request, 'Ya has solicitado un servicio en esta categoría.')
                    return redirect('solicitarServices')

                nueva_solicitud.save()
                messages.success(request, 'Servicio solicitado exitosamente.')
                return redirect('solicitarServices')
            else:
                messages.error(request, 'Por favor, corrige los errores en el formulario.')
                # Puedes también devolver el formulario con errores si lo prefieres
                # return render(request, 'solicitarServicio/solicitarServicio.html', {'formSolicitarServices': formSolicitarServices})
        except Exception as e:
            messages.error(request, f'Ocurrió un error: {str(e)}')

        return redirect('solicitarServices')  # Puedes redirigir a la página que prefieras en caso de error
   
    
def MisServicesJson(request):
    if request.method == 'GET':
        services = SolicitudServicio.objects.filter(solicitado_por=request.user)

        # Convertir los datos a una lista de diccionarios
        services_data = [
            {
                'id': service.id,
                'categoria': service.categoria,
                'descripcion': service.descripcion,
                'ubicacion': service.ubicacion,
                'img_url': service.img.url if service.img else None,  # Ajusta según tu modelo
                'reseñas': obtener_reseñas(service.id)  # Obtener reseñas para este servicio
            }
            for service in services
        ]

        # Devolver los datos como JSON
        return JsonResponse({'services': services_data})

def obtener_reseñas(servicio_id):  # Corregir aquí: servicio_id como parámetro
    # Obtener las reseñas para un servicio específico
    reseñas = Reseña.objects.filter(servicio__solicitud__id=servicio_id)

    # Convertir los datos a una lista de diccionarios
    reseñas_data = [
        {
            'usuario': reseña.usuario.username,
            'texto': reseña.texto,
            'calificacion': reseña.calificacion,
            'calificacion_estrellas': reseña.calificacion_estrellas
        }
        for reseña in reseñas
    ]

    return reseñas_data

def MeServices(request):
    if request.method == 'GET':
        return render(request, 'solicitarServicio/miServicio.html')
    

def ver_reseñas(request):
    servicio_id = request.GET.get('servicio_id')

    # Validar que el parámetro servicio_id es un número válido
    try:
        servicio_id = int(servicio_id)
    except (ValueError, TypeError):
        return JsonResponse({'error': 'Invalid servicio_id'})

    try:
        # Obtener la solicitud específica
        solicitud_servicio = get_object_or_404(SolicitudServicio, id=servicio_id)

        # Obtener el servicio relacionado con la solicitud
        servicio = get_object_or_404(Servicio, solicitud=solicitud_servicio)

        # Obtener las reseñas relacionadas con ese servicio
        serviciosReseña = Reseña.objects.filter(servicio=servicio)

        # Verificar si hay reseñas
        if serviciosReseña.exists():
            return render(request, 'ver_reseñas.html', {'servicio_id': servicio_id, 'serviciosReseña': serviciosReseña})
        else:
            messages.error(request, 'No hay reseñas para este servicio.')
            return redirect('MeServices')
    except:
        messages.error(request, 'No se pudo encontrar el servicio o no hay reseñas para este servicio')
        return redirect('MeServices')
