
from django.db import models
from django.contrib.auth.models import User

from apps.usuario.models import PerfilUsuario


# Create your models here.

class SolicitudServicio(models.Model):
    OPCIONES_CATEGORIA = [
        ('C', 'Carpintería'),
        ('P', 'Plomería'),
        ('E', 'Electricidad'),
        ('L', 'Limpieza')
    ]

    categoria = models.CharField(max_length=250, choices=OPCIONES_CATEGORIA)
    descripcion = models.TextField()
    solicitado_por = models.ForeignKey(User, on_delete=models.CASCADE)
    ubicacion = models.CharField(max_length=255)
    img = models.ImageField(upload_to='servicios', null=True, blank=True)

    def get_categoria_display_name(self):
        return dict(self.OPCIONES_CATEGORIA)[self.categoria]

    def __str__(self):
        return f"{self.get_categoria_display_name()} - {self.solicitado_por}"


class Servicio(models.Model):
    solicitud = models.OneToOneField(SolicitudServicio, on_delete=models.CASCADE)
    trabajador = models.ForeignKey(PerfilUsuario, on_delete=models.CASCADE)
    aceptado_en = models.DateTimeField(null=True)

    def __str__(self):
        return f'Servicio #{self.id} - Trabajador: {self.trabajador} - Solicitud: {self.solicitud}'