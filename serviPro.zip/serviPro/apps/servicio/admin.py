from django.contrib import admin

from apps.servicio.models import Servicio, SolicitudServicio

# Register your models here.
admin.site.register(Servicio)
admin.site.register(SolicitudServicio)