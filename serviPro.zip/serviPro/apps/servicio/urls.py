from django.contrib.auth.decorators import login_required
from django.urls import path
from . import views


urlpatterns = [
path('servicios/', login_required(views.servicios), name='servicios'),
path('ver_trabajadores/<str:categoria_servicio>/', login_required(views.ver_trabajadores_servicio), name='ver_trabajadores_servicio'),
path('contratarServicio/<int:id_categoria_servicio>/', login_required(views.contratar_servicio), name='contratar_servicio'),
path('solicitarServicio/', login_required(views.SolicitarServices), name='solicitarServices'),
path('MeServiciosJson/', login_required(views.MisServicesJson), name='MeServicesJson'),
path('MeServicios/', login_required(views.MeServices), name='MeServices'),
path('ver-reseñas/', login_required(views.ver_reseñas), name='ver_reseñas'),
path('obtenerReseñas/', login_required(views.obtener_reseñas), name='obtener_reseñas'),
path('MeServiciosTrabajador/', login_required(views.MeServicioTrabajador), name='MeServiciosTrabajador'),
path('ver_resenasT/<int:servicio_id>/', views.ver_resenas, name='ver_resenasT'),


]

