from django import forms
from .models import Servicio, SolicitudServicio

class ContratarServiceForm(forms.ModelForm):
    class Meta:
        model = Servicio
        fields = ['aceptado_en']

class SolicitarServicesForm(forms.ModelForm):
    class Meta:
        model =  SolicitudServicio
        fields = ['categoria', 'descripcion', 'ubicacion', 'img']
        
# En tu archivo forms.py


class ResenaForm(forms.Form):
    servicio_id = forms.IntegerField(widget=forms.HiddenInput())
    texto = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 3}), required=True)
    calificacion = forms.IntegerField(widget=forms.NumberInput(attrs={'class': 'form-control', 'min': 1, 'max': 5}), required=True)
